@echo off
net session >nul 2>&1
if errorlevel 1 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
cd /d "%~dp0"
echo Y540 read-only firmware dump. Reads the keyboard's firmware, writes nothing.
echo The keyboard switches off for about a minute, then comes back.
echo Keep the charger connected and do not touch the keyboard until it finishes.
echo.
Y540Updater.exe --dump-all SHFU.ini
echo.
powershell -NoProfile -Command "Get-ChildItem -LiteralPath '%~dp0logs' -Filter 'flash-dump-FULL*.bin' | ForEach-Object { 'FILE: ' + $_.Name; 'SIZE: ' + $_.Length; 'SHA256: ' + (Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash }"
echo.
echo Finished. Attach the whole "logs" folder (zipped) to your GitHub issue.
pause
