@echo off
rem Opens the Y540 keyboard updater as administrator.
rem Nothing is written until you click "Advanced firmware write" and confirm.
powershell.exe -NoProfile -Command "Start-Process -FilePath \"%~dp0Y540Updater.exe\" -WorkingDirectory \"%~dp0.\" -Verb RunAs"
